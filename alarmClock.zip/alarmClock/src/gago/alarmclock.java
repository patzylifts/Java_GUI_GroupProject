package gago;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class alarmclock extends JFrame implements ActionListener {
    private JTextField alarmTimeTextField;
        
    JButton alarmButton;
    JButton startButton;
    JButton resetButton;
    JLabel timeLabel;
    JComboBox alarmTimeHour;
    JComboBox alarmTimeMinutes;
    JComboBox alarmTimeSeconds;
    boolean started = false;
    Clip clip;
    public alarmclock() {
        setTitle("Alarm Clock");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setSize(300, 100);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(0x9BA4B5));
        setLayout(new FlowLayout());
        setVisible(true);
        setResizable(false);

        JLabel alarmTimeLabel = new JLabel("Alarm Time:");
        alarmTimeLabel.setForeground(new Color(0x212A3E));
        alarmTimeTextField = new JTextField(10);
        alarmTimeTextField.setBackground(new Color(0x212A3E));
        alarmTimeTextField.setForeground(new Color(0xF1F6F9));


        String hour[] = setOptionItems(23);
        String minute[] = setOptionItems(59);
	String seconds[] = setOptionItems(59);

	alarmTimeHour = new JComboBox(hour);
	alarmTimeHour.setBackground(new Color(0x212A3E));
         alarmTimeHour.setForeground(new Color(0xF1F6F9));

	alarmTimeMinutes = new JComboBox(minute);
	alarmTimeMinutes.setBackground(new Color(0x212A3E));
         alarmTimeMinutes.setForeground(new Color(0xF1F6F9));
	
	alarmTimeSeconds = new JComboBox(seconds);
	alarmTimeSeconds.setBackground(new Color(0x212A3E));
	alarmTimeSeconds.setForeground(new Color(0xF1F6F9));
        
        JButton setAlarmButton = new JButton("Set Alarm");
        setAlarmButton.setBackground(new Color(0x212A3E));
        setAlarmButton.setForeground(new Color(0xF1F6F9));
        
        alarmTimeTextField.setForeground(new Color(0xF1F6F9));
        
        setAlarmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
		String alarmTime = alarmTimeHour.getSelectedItem() + ":" + alarmTimeMinutes.getSelectedItem() + ":" +alarmTimeSeconds.getSelectedItem();
		startAlarm(alarmTime);
            }
        });

	add(alarmTimeLabel);
	add(alarmTimeHour);
      	add(alarmTimeMinutes);
	add(alarmTimeSeconds);
	add(setAlarmButton);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new alarmclock();
            }
        });
    }

        @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==alarmButton) {

            if(started==false) {
                started=true;
                alarmButton.setText("STOP");
                start();
            }
            else {
                started=false;
                startButton.setText("START");
                stop();
            }

        }
        if(e.getSource()==resetButton) {
            started=false;
            startButton.setText("START");
            reset();
        }

    }
    
    private void startAlarm(String alarmTime) {
        LocalTime now = LocalTime.now();
        LocalTime alarm = LocalTime.parse(alarmTime);

        long delay = Math.abs(java.time.Duration.between(now, alarm).toMillis());

        Timer timer = new Timer((int) delay, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
		playAudio();
                 JOptionPane.showMessageDialog(alarmclock.this, "Alarm!");
		clip.stop();
            }
        });

        timer.setRepeats(false);
        timer.start();
    }

    private String[] setOptionItems(int num){
	String[] arr = new String[num+1];
    	for (int i = 0; i <= num; i++){
		if (i<10){
		 	arr[i] =  "0" + i;
		}else{
		 	arr[i] = "" + i;
		}
	}
	return arr;
    }

    public void playAudio(){
	try{
       		AudioInputStream audioInputStream = 
                 AudioSystem.getAudioInputStream(new File("alarm.wav").getAbsoluteFile());
	        	clip = AudioSystem.getClip();
        		clip.open(audioInputStream);
        		clip.loop(Clip.LOOP_CONTINUOUSLY);
	}catch (Exception ex) {
            System.out.println("Error with playing sound.");
            ex.printStackTrace();
          
         }

    }

    private void start() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void stop() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void reset() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
